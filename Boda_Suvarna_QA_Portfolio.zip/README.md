# Boda Suvarna — QA Automation Portfolio

Professional portfolio for Boda Suvarna, Senior Quality Engineer Analyst / QA Automation Engineer.

## Stack
- React
- Vite
- Lucide React
- Responsive CSS

## Run locally

```bash
npm install
npm run dev
```

## Build

```bash
npm run build
```

## Deploy
This project can be deployed to Vercel, Netlify, or GitHub Pages.

## Resume
Place the provided resume PDF in the `public/` folder as:

`Boda_Suvarna_Resume.pdf`

The portfolio already includes a download button pointing to that file.
