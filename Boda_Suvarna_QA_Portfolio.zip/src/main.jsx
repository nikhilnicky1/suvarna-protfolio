import React from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUpRight, CheckCircle2, ChevronRight, Code2, Database,
  Download, Github, Globe2, Layers3, Linkedin, Mail, Menu,
  ServerCog, ShieldCheck, Sparkles, X, Zap
} from "lucide-react";
import "./styles.css";

const skills = [
  ["UI Automation", "Selenium WebDriver, Selenium Grid, Page Object Model, Cucumber / BDD"],
  ["Programming", "JavaScript, Node.js, SQL"],
  ["API & Backend", "Postman, API test design, backend validation, data reconciliation"],
  ["Data Validation", "MySQL, AWS Athena, Google BigQuery"],
  ["Test Ecosystem", "QTest, JIRA, Azure DevOps, Maven, BrowserStack"],
  ["Quality Practices", "Functional, regression, smoke, sanity, database, data integrity, cross-browser"]
];

const projects = [
  {
    number: "01",
    client: "The Walt Disney Company",
    title: "Real-Time Shipboard Systems QA",
    tag: "UI Automation",
    description: "Built and maintained Node.js and Cucumber automation for a shipboard UI application, with coverage focused on real-time operational workflows.",
    stack: ["Node.js", "Cucumber", "AWS Kiro", "JIRA", "QTest"],
    outcome: "200+ defects tracked with stronger automation-result traceability."
  },
  {
    number: "02",
    client: "ExxonMobil Corporation",
    title: "Enterprise Energy Platform QA",
    tag: "Enterprise Automation",
    description: "Automated critical regression scenarios with Selenium WebDriver and Cucumber, complemented by API validation and cross-browser execution.",
    stack: ["Selenium", "Cucumber", "Postman", "BrowserStack", "Azure DevOps"],
    outcome: "200+ test cases automated and regression coverage increased by 40%."
  },
  {
    number: "03",
    client: "New York Life",
    title: "Group Insurance Platform QA",
    tag: "UI + Data",
    description: "Engineered reusable Selenium/POM automation and validated end-to-end UI workflows alongside database operations using AWS Athena.",
    stack: ["Selenium", "POM", "Cucumber", "AWS Athena", "QTest"],
    outcome: "50+ automation scripts supporting functional and regression releases."
  },
  {
    number: "04",
    client: "Accenture CIO",
    title: "EPS Transformation — HR & Payroll",
    tag: "Data Validation",
    description: "Automated enterprise HR and payroll scenarios while validating large datasets and business data integrity in Google BigQuery.",
    stack: ["Selenium", "POM", "Cucumber", "BigQuery", "Azure DevOps"],
    outcome: "220+ scenarios automated with test execution time reduced by 30%."
  }
];

const experience = [
  {
    period: "Aug 2022 — Present",
    role: "Quality Engineering Analyst",
    company: "Accenture Private Limited",
    bullets: [
      "Led automation of critical workflows using Selenium, POM, Cucumber and Node.js.",
      "Executed 600+ functional, regression, smoke, API and database test cases.",
      "Reduced manual regression effort by 35% and improved test coverage by 45%."
    ]
  },
  {
    period: "Oct 2021 — Aug 2022",
    role: "Quality Engineering Associate",
    company: "Accenture Private Limited",
    bullets: [
      "Automated enterprise HR and payroll scenarios using Selenium, POM and Cucumber.",
      "Validated enterprise datasets with Google BigQuery.",
      "Supported release stability through Azure DevOps, QTest and Agile ceremonies."
    ]
  }
];

function SectionTitle({ eyebrow, title, children }) {
  return (
    <div className="section-title">
      <div>
        <span className="eyebrow">{eyebrow}</span>
        <h2>{title}</h2>
      </div>
      {children}
    </div>
  );
}

function App() {
  const [open, setOpen] = React.useState(false);

  const nav = [
    ["About", "about"],
    ["Skills", "skills"],
    ["Projects", "projects"],
    ["Experience", "experience"],
    ["Contact", "contact"]
  ];

  const go = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
    setOpen(false);
  };

  return (
    <div className="site">
      <header className="nav-wrap">
        <nav className="nav">
          <button className="brand" onClick={() => go("home")}>
            <span className="brand-mark">BS</span>
            <span>Boda Suvarna</span>
          </button>
          <div className={`nav-links ${open ? "open" : ""}`}>
            {nav.map(([label, id]) => (
              <button key={id} onClick={() => go(id)}>{label}</button>
            ))}
            <a className="nav-cta" href="mailto:suvarnaboda123@gmail.com">Let's connect <ArrowUpRight size={15}/></a>
          </div>
          <button className="menu" onClick={() => setOpen(!open)} aria-label="Toggle navigation">
            {open ? <X/> : <Menu/>}
          </button>
        </nav>
      </header>

      <main>
        <section id="home" className="hero">
          <div className="hero-copy">
            <div className="availability"><span></span> QA Automation Engineer</div>
            <h1>Engineering confidence<br/><em>through automation.</em></h1>
            <p className="hero-lead">
              Senior Quality Engineer Analyst with 4+ years of enterprise QA experience,
              specializing in UI automation, BDD, API validation and data integrity.
            </p>
            <div className="hero-actions">
              <button className="primary" onClick={() => go("projects")}>Explore my work <ArrowUpRight size={17}/></button>
              <a className="secondary" href="/Boda_Suvarna_Resume.pdf" download>Download resume <Download size={16}/></a>
            </div>
            <div className="hero-meta">
              <span>Based in Hyderabad, India</span>
              <span>Open to quality engineering opportunities</span>
            </div>
          </div>

          <div className="hero-panel">
            <div className="panel-top"><span>QUALITY ENGINEERING</span><span>01 / 04</span></div>
            <div className="terminal">
              <div className="terminal-head"><span className="dots">● ● ●</span><span>automation-suite</span></div>
              <div className="terminal-body">
                <p><b className="blue">describe</b>(<span className="green">"critical workflow"</span>)</p>
                <p className="indent"><b className="blue">it</b>(<span className="green">"should validate end-to-end"</span>, <span className="purple">async</span> () =&gt; {'{'}</p>
                <p className="indent2"><b className="blue">await</b> browser.navigate(url);</p>
                <p className="indent2"><b className="blue">await</b> page.login(user);</p>
                <p className="indent2"><b className="blue">await</b> page.assertWorkflow();</p>
                <p className="indent">{'}'});</p>
                <div className="terminal-result"><CheckCircle2 size={16}/> PASS — workflow validated</div>
              </div>
            </div>
            <div className="panel-bottom">
              <div><strong>600+</strong><span>test cases</span></div>
              <div><strong>45%</strong><span>coverage increase</span></div>
              <div><strong>35%</strong><span>less regression effort</span></div>
            </div>
          </div>
        </section>

        <section className="metrics">
          <div><span>01</span><strong>4+ years</strong><small>QA automation experience</small></div>
          <div><span>02</span><strong>600+</strong><small>test cases executed</small></div>
          <div><span>03</span><strong>45%</strong><small>test coverage increase</small></div>
          <div><span>04</span><strong>35%</strong><small>manual effort reduced</small></div>
        </section>

        <section id="about" className="section about">
          <SectionTitle eyebrow="01 — About" title="Quality engineering with an outcome-first mindset." />
          <div className="about-grid">
            <div className="about-text">
              <p className="large">I build reliable automation that helps teams ship with confidence.</p>
              <p>My experience spans Financial Services, Energy and Entertainment, supporting enterprise applications for Fortune 500 clients including The Walt Disney Company, ExxonMobil and New York Life.</p>
              <p>I work across the full quality lifecycle — from reusable UI automation and BDD scenarios to API validation, backend/database checks, test data management and defect traceability.</p>
            </div>
            <div className="about-card">
              <span className="card-icon"><ShieldCheck/></span>
              <h3>Quality is more than passing tests.</h3>
              <p>It is about creating fast feedback, trustworthy data, maintainable automation and clear visibility into release risk.</p>
            </div>
          </div>
        </section>

        <section id="skills" className="section skills-section">
          <SectionTitle eyebrow="02 — Expertise" title="Tools I use to build dependable test systems." />
          <div className="skills-grid">
            {skills.map(([title, text], i) => (
              <article className="skill-card" key={title}>
                <span className="skill-no">0{i+1}</span>
                <h3>{title}</h3>
                <p>{text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="section architecture">
          <SectionTitle eyebrow="03 — Approach" title="From scenario to actionable feedback." />
          <div className="flow">
            {[
              ["01","BDD / Test Design","Readable scenarios aligned to business workflows"],
              ["02","Page Objects","Reusable components and maintainable locators"],
              ["03","Execution","Selenium WebDriver, Grid and cross-browser validation"],
              ["04","Validation","API, database and data-integrity checks"],
              ["05","Reporting","Defect traceability, execution results and release feedback"]
            ].map(([n,t,d], i) => (
              <React.Fragment key={n}>
                <div className="flow-item"><span>{n}</span><div><h3>{t}</h3><p>{d}</p></div></div>
                {i < 4 && <ChevronRight className="flow-arrow" size={18}/>}
              </React.Fragment>
            ))}
          </div>
        </section>

        <section id="projects" className="section projects-section">
          <SectionTitle eyebrow="04 — Selected work" title="Enterprise projects, measurable outcomes." />
          <div className="projects">
            {projects.map(p => (
              <article className="project" key={p.number}>
                <div className="project-number">{p.number}</div>
                <div className="project-main">
                  <div className="project-top"><span>{p.client}</span><span className="tag">{p.tag}</span></div>
                  <h3>{p.title}</h3>
                  <p>{p.description}</p>
                  <div className="stack">{p.stack.map(s => <span key={s}>{s}</span>)}</div>
                </div>
                <div className="project-outcome"><span>OUTCOME</span><strong>{p.outcome}</strong></div>
              </article>
            ))}
          </div>
        </section>

        <section id="experience" className="section experience">
          <SectionTitle eyebrow="05 — Experience" title="A track record of automation and delivery." />
          <div className="timeline">
            {experience.map((e, i) => (
              <div className="timeline-row" key={e.period}>
                <div className="period">{e.period}</div>
                <div className="timeline-dot"></div>
                <div className="timeline-content">
                  <h3>{e.role}</h3><h4>{e.company}</h4>
                  <ul>{e.bullets.map(b => <li key={b}>{b}</li>)}</ul>
                </div>
              </div>
            ))}
          </div>
          <div className="award">
            <Sparkles size={18}/><span><strong>Excellence of Commitment Award</strong> — recognized at Accenture for consistent performance and proactive contributions.</span>
          </div>
        </section>

        <section className="section education">
          <div className="education-card">
            <div><span className="eyebrow">Education</span><h2>B.Tech — Electrical & Electronics Engineering</h2><p>SR University · 2017–2021 · CGPA 9.52 / 10</p></div>
            <div className="edu-icon"><Code2 size={24}/></div>
          </div>
        </section>

        <section id="contact" className="contact">
          <div className="contact-inner">
            <span className="eyebrow">06 — Contact</span>
            <h2>Let's build better<br/><em>quality together.</em></h2>
            <p>For automation engineering opportunities, collaboration or a conversation about quality engineering, get in touch.</p>
            <a className="contact-mail" href="mailto:suvarnaboda123@gmail.com">suvarnaboda123@gmail.com <ArrowUpRight/></a>
            <div className="contact-links">
              <a href="https://www.linkedin.com/in/suvarna-boda-0a8189194" target="_blank" rel="noreferrer"><Linkedin size={17}/> LinkedIn</a>
              <a href="mailto:suvarnaboda123@gmail.com"><Mail size={17}/> Email</a>
            </div>
          </div>
        </section>
      </main>

      <footer>
        <span>© {new Date().getFullYear()} Boda Suvarna</span>
        <span>QA Automation Engineer · Hyderabad, India</span>
        <button onClick={() => go("home")}>Back to top ↑</button>
      </footer>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
